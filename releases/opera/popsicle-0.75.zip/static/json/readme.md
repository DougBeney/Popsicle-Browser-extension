# Enjoy these quotes!

Use them in any of your projects.

Quotes were compiled using my Node.js scraper, [quote-crawl](https://github.com/DougBeney/quote-crawl).
